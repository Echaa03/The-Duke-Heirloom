# Duke Heirloom — Document Inspection System (Unity 6, uGUI)

Zoomable document + highlighter + findings sticky notes + MC textbox.
Built for Scene 1.2 (INSPECTION-01 police report, -02 phone status, -03 bank statement).

## 1. Install
1. Copy the `Scripts` folder into `Assets/DukeHeirloom/Inspection/`.
2. Don't use Ink? Delete `Scripts/Optional_Ink/`.
3. If TextMeshPro asks to import **TMP Essentials**, click Import.

## 2. Try the demo (2 minutes)
1. Open an empty scene → **Tools ▸ Duke Heirloom ▸ Create Inspection Screen**.
2. Press Play.
3. Highlighter is ON. Swipe left→right across **"Witness (friend): …21:00"**.
   MC says the partial line ("this doesn't sit right…").
4. Swipe across **"Statement (family): …never returned home"**.
   Strokes flash, the yellow sticky note pops in, MC's textbox plays.
5. Click the sticky note → the page zooms back to the finding.

Controls: mouse wheel = zoom toward cursor · right/middle drag = pan (always) ·
left drag = pan when highlighter is OFF · Erase = remove highlights that didn't count ·
Space / Enter / click = advance text.

## 3. Bring in your Figma report
1. In Figma, hide the textbox + sticky note layers (those are live Unity UI, so their text stays editable).
2. Export the report frame as **PNG @2x**.
3. Unity import settings: Texture Type **Sprite (2D and UI)**, Max Size **4096**,
   Compression **None** (or High Quality), **Generate Mip Maps ON**, Filter **Trilinear**.
   (2x + mipmaps = text stays sharp both zoomed in and zoomed out.)
4. Select `Content (= Figma frame size)` → set Width/Height to the frame's **1x** size
   (e.g. 1240 × 1754).
5. Drag the PNG into `Document (your Figma PNG)` → Image → Source Image, set color to white.
6. Delete the `PH_…` placeholder objects.

## 4. Place the findings
Each finding = one `FindingZone` with one or more **Line** rects over the exact text.
ALL lines must be highlighted (≥ 70% each by default) → good for contradictions,
e.g. friend's statement + family's statement.

Easiest placement: each Line has a **FigmaRect** component.
In Figma select the text → copy X / Y / W / H (relative to the frame) →
paste into FigmaRect → right-click the component header → **Apply Figma Rect**.
Lines show as orange boxes in the Scene view only (green when found).

Also set **HighlighterTool ▸ Stroke Height** ≈ your report's line height.

To add a finding: duplicate `Finding_TimeMismatch`, change `id`, lines, sticky text and dialogue.

## 5. One document per screen
Make the police report, phone status and bank statement separate InspectionScreens
(or prefabs). When every finding on a screen is found, the board:
- plays `All Found Dialogue` (optional),
- shows the Continue button,
- fires `onAllFindingsFound` → hook this to load the next document / return to the story.

`onFindingFound(string id)` fires per finding (useful for an evidence log later — e.g. the
"Professor call" evidence used in the 3.10 debate).

## 6. Ink (optional)
Add `InkInspectionSource` anywhere, give it the compiled `inspection.ink` JSON, and drag it into
**InspectionBoard ▸ Dialogue Source**. A zone's `Ink Knot` field then plays that knot instead of
the inspector lines; `<knot>_partial` is used for the partial line if it exists.
Line format: `MC (inner): text`, `PROF: text`, or plain narration.

## 7. Connecting to your VN scene (BG-01 → inspection → Scene 1.3)
1. Select your VN Canvas, then run **Tools ▸ Duke Heirloom ▸ Create Inspection Screen**.
   It builds `Inspections` inside YOUR canvas.
2. In the Hierarchy, drag `Inspections` so it sits **below the BG and above your textbox**
   (BG-01 behind the document, your textbox on top).
3. Use your own textbox: on `Inspection_police_report ▸ Textbox`, drag your textbox
   into **Panel**, your name text into **Name Text**, body text into **Body Text**, tick **Shared With VN**,
   then delete the builder's `Panel (put your textbox art here)` child.
4. Duplicate `Inspection_police_report` twice → set **Inspection Id** to `phone_status` and
   `bank_statement`, swap their document art and findings.
5. In your dialogue manager add the 3 lines marked ★ in `Optional_Ink/VNInkExample.cs`.
6. In Ink, put `#inspect:<id>` on the line right before the document should open
   (see `Optional_Ink/prologue_act1.ink`).
7. Clear **Test Open On Start** on `Inspections` once the story opens documents itself.

Flow: line with `#inspect:police_report` is shown → player clicks → document fades in over BG-01 →
findings → (Continue) → fades out → `story.Continue()` → next line.

## 8. Tuning cheat-sheet
| Where | Field | What it does |
|---|---|---|
| FindingZone | Required Coverage | how much of each line must be highlighted |
| FindingZone | Max Overhang | stops "highlight the whole page" cheese |
| FindingZone | Hint | MC's nudge after repeated wrong highlights |
| InspectionBoard | Hint Every Wrong Strokes | how often MC comments on wrong highlights |
| DocumentZoomPan | Max Zoom Multiplier | max zoom vs. "fit page" |
| HighlighterTool | Stroke Sprite / Cursor Texture | swap in highlighter art |
