using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DukeHeirloom.Inspection
{
    /// <summary>
    /// The brain of one inspection screen (one document: police report, phone status, bank statement...).
    /// Receives highlighter strokes, checks them against FindingZones, spawns sticky notes and plays dialogue.
    /// Wire onAllFindingsFound (or the Continue button) to go back to your story.
    /// </summary>
    public class InspectionBoard : MonoBehaviour
    {
        [Tooltip("Name used by the Ink tag, e.g. #inspect:police_report → 'police_report'.")]
        public string inspectionId = "police_report";

        [Header("References")]
        [SerializeField] DocumentZoomPan zoomPan;
        [SerializeField] HighlighterTool highlighter;
        [SerializeField] RectTransform strokeLayer;
        [SerializeField] InspectionTextbox textbox;
        [SerializeField] RectTransform stickyNoteArea;
        [SerializeField] StickyNote stickyNotePrefab;
        [Tooltip("Button image tinted to show whether the highlighter is on.")]
        [SerializeField] Graphic highlighterIndicator;
        [Tooltip("Optional. If set, the player presses it to leave; if empty, the screen closes by itself.")]
        [SerializeField] GameObject continueButton;
        [Tooltip("Optional: a component implementing IInspectionDialogueSource (e.g. InkInspectionSource).")]
        [SerializeField] MonoBehaviour dialogueSource;
        [Tooltip("Leave empty to auto-collect every FindingZone under this object.")]
        [SerializeField] List<FindingZone> zones = new List<FindingZone>();

        [Header("Look")]
        [SerializeField] Color confirmedColor = new Color(1f, 0.82f, 0.1f, 0.55f);
        [SerializeField] Color indicatorOn = new Color(1f, 0.85f, 0.2f, 1f);
        [SerializeField] Color indicatorOff = new Color(0.12f, 0.1f, 0.08f, 0.85f);
        [SerializeField, Min(0f)] float wrongStrokeFade = 0.6f;

        [Header("Flow")]
        [SerializeField] bool startWithHighlighterOn = true;
        [SerializeField] List<DialogueLine> introDialogue = new List<DialogueLine>();
        [Tooltip("Every Nth wrong highlight, MC says the current finding's hint (or one of these if it has none).")]
        [SerializeField, Min(1)] int hintEveryWrongStrokes = 3;
        [SerializeField] List<DialogueLine> wrongHighlightLines = new List<DialogueLine>
        {
            new DialogueLine("MC", "No... that part checks out."),
            new DialogueLine("MC", "Nothing strange here. Keep reading."),
            new DialogueLine("MC", "That's just standard procedure. Not it."),
        };
        [SerializeField] List<DialogueLine> allFoundDialogue = new List<DialogueLine>();

        [Header("Events")]
        public UnityEvent<string> onFindingFound = new UnityEvent<string>();
        public UnityEvent onAllFindingsFound = new UnityEvent();
        [Tooltip("Player is done with this document (after Continue, or right after the last line if there's no button).")]
        public UnityEvent onFinished = new UnityEvent();
        bool finished;

        class Stroke
        {
            public Image image;
            public Rect rect;
            public bool confirmed;
        }

        readonly List<Stroke> strokes = new List<Stroke>();
        readonly List<Vector2> intervals = new List<Vector2>();
        static readonly Vector3[] corners = new Vector3[4];
        int wrongCount;
        bool busy;

        public bool CanHighlight => !busy && (textbox == null || !textbox.IsPlaying);
        public bool IsComplete { get; private set; }
        IInspectionDialogueSource Source => dialogueSource as IInspectionDialogueSource;

        void Start()
        {
            if (zones.Count == 0) GetComponentsInChildren(true, zones);
            if (continueButton != null) continueButton.SetActive(false);
            if (stickyNotePrefab != null && stickyNotePrefab.gameObject.scene.IsValid())
                stickyNotePrefab.gameObject.SetActive(false); // template lives in the scene
            SetHighlighter(startWithHighlighterOn);
            Say(introDialogue, null);
        }

        // ---------- buttons ----------

        public void ToggleHighlighter() => SetHighlighter(highlighter == null || !highlighter.IsOn);

        public void SetHighlighter(bool on)
        {
            if (highlighter != null) highlighter.SetOn(on);
            if (zoomPan != null) zoomPan.leftDragPans = !on;
            if (highlighterIndicator != null) highlighterIndicator.color = on ? indicatorOn : indicatorOff;
        }

        /// <summary>Erase highlights that didn't lead to a finding.</summary>
        public void ClearHighlights()
        {
            for (int i = strokes.Count - 1; i >= 0; i--)
            {
                if (strokes[i].confirmed) continue;
                if (strokes[i].image != null) Destroy(strokes[i].image.gameObject);
                strokes.RemoveAt(i);
            }
        }

        // ---------- called by HighlighterTool ----------

        public void SubmitStroke(Image image, Rect rect)
        {
            var stroke = new Stroke { image = image, rect = rect };
            strokes.Add(stroke);

            bool touchedAnything = false;
            FindingZone partialZone = null;

            foreach (var zone in zones)
            {
                if (zone == null || zone.IsFound) continue;

                int covered = 0, total = 0;
                bool touches = false;
                var contributing = new List<Stroke>();
                foreach (var line in zone.Targets)
                {
                    if (line == null) continue;
                    total++;
                    if (LineCoverage(zone, line, stroke, contributing, ref touches) >= zone.requiredCoverage) covered++;
                }
                touchedAnything |= touches;

                if (total > 0 && covered == total)
                {
                    FoundZone(zone, contributing);
                    return;
                }
                if (touches && covered > 0 && !zone.partialPlayed && partialZone == null) partialZone = zone;
            }

            if (partialZone != null)
            {
                partialZone.partialPlayed = true;
                Say(GetLines(partialZone.inkKnot, "_partial", partialZone.partialDialogue), null);
                return;
            }

            if (touchedAnything)
            {
                wrongCount = 0; // on the right track, keep the stroke
                return;
            }

            // Wrong spot: fade the stroke away, and every few misses let MC think out loud.
            StartCoroutine(FadeAndRemove(stroke));
            wrongCount++;
            if (wrongCount % hintEveryWrongStrokes == 0) SayHint();
        }

        // ---------- checking ----------

        /// <returns>Fraction (0..1) of the line's width that is highlighted.</returns>
        float LineCoverage(FindingZone zone, RectTransform line, Stroke newest, List<Stroke> contributing, ref bool newestTouches)
        {
            Rect L = ToStrokeSpace(line);
            if (L.width <= 0f) return 0f;
            intervals.Clear();

            foreach (var s in strokes)
            {
                Rect r = s.rect;
                float yOverlap = Mathf.Min(L.yMax, r.yMax) - Mathf.Max(L.yMin, r.yMin);
                if (yOverlap < Mathf.Min(L.height, r.height) * 0.4f) continue;

                float x0 = Mathf.Max(L.xMin, r.xMin), x1 = Mathf.Min(L.xMax, r.xMax);
                if (x1 <= x0) continue;
                if (r.width - (x1 - x0) > L.width * zone.maxOverhang) continue; // scribbled way past the text

                intervals.Add(new Vector2(x0, x1));
                if (!contributing.Contains(s)) contributing.Add(s);
                if (s == newest) newestTouches = true;
            }

            if (intervals.Count == 0) return 0f;
            intervals.Sort((a, b) => a.x.CompareTo(b.x));
            float covered = 0f, curStart = intervals[0].x, curEnd = intervals[0].y;
            for (int i = 1; i < intervals.Count; i++)
            {
                if (intervals[i].x <= curEnd) curEnd = Mathf.Max(curEnd, intervals[i].y);
                else
                {
                    covered += curEnd - curStart;
                    curStart = intervals[i].x;
                    curEnd = intervals[i].y;
                }
            }
            covered += curEnd - curStart;
            return covered / L.width;
        }

        Rect ToStrokeSpace(RectTransform rt)
        {
            rt.GetWorldCorners(corners);
            Vector2 a = strokeLayer.InverseTransformPoint(corners[0]);
            Vector2 b = strokeLayer.InverseTransformPoint(corners[2]);
            return Rect.MinMaxRect(Mathf.Min(a.x, b.x), Mathf.Min(a.y, b.y), Mathf.Max(a.x, b.x), Mathf.Max(a.y, b.y));
        }

        // ---------- results ----------

        void FoundZone(FindingZone zone, List<Stroke> contributing)
        {
            zone.IsFound = true;
            wrongCount = 0;
            foreach (var s in contributing)
            {
                s.confirmed = true;
                if (s.image != null) StartCoroutine(Flash(s.image));
            }

            if (stickyNotePrefab != null && stickyNoteArea != null)
            {
                var note = Instantiate(stickyNotePrefab, stickyNoteArea);
                note.gameObject.SetActive(true);
                note.name = "Sticky_" + zone.id;
                note.Setup(zone.stickyTitle, zone.stickyText, () => FocusZone(zone));
            }

            onFindingFound.Invoke(zone.id);
            Say(GetLines(zone.inkKnot, "", zone.dialogue), AfterFinding);
        }

        void AfterFinding()
        {
            foreach (var z in zones)
                if (z != null && !z.IsFound) return;

            IsComplete = true;
            Say(allFoundDialogue, () =>
            {
                onAllFindingsFound.Invoke();
                if (continueButton != null) continueButton.SetActive(true);
                else Finish();
            });
        }

        /// <summary>Hook the Continue button here. Leaves this document.</summary>
        public void Finish()
        {
            if (finished || !IsComplete) return;
            finished = true;
            if (continueButton != null) continueButton.SetActive(false);
            onFinished.Invoke();
        }

        /// <summary>Zoom the document to a finding (used when clicking its sticky note).</summary>
        public void FocusZone(FindingZone zone)
        {
            if (zoomPan == null || zone == null) return;
            Vector2 sum = Vector2.zero;
            int n = 0;
            foreach (var line in zone.Targets)
            {
                if (line == null) continue;
                sum += (Vector2)zoomPan.Content.InverseTransformPoint(line.TransformPoint(line.rect.center));
                n++;
            }
            if (n > 0) zoomPan.FocusOnLocal(sum / n);
        }

        void SayHint()
        {
            foreach (var z in zones)
            {
                if (z == null || z.IsFound || string.IsNullOrWhiteSpace(z.hint)) continue;
                Say(new List<DialogueLine> { new DialogueLine("MC", z.hint) }, null);
                return;
            }
            if (wrongHighlightLines.Count > 0)
                Say(new List<DialogueLine> { wrongHighlightLines[Random.Range(0, wrongHighlightLines.Count)] }, null);
        }

        List<DialogueLine> GetLines(string knot, string suffix, List<DialogueLine> fallback)
        {
            if (Source != null && !string.IsNullOrWhiteSpace(knot))
            {
                var fromSource = new List<DialogueLine>();
                if (Source.TryGetLines(knot + suffix, fromSource, quiet: suffix.Length > 0)) return fromSource;
            }
            return fallback;
        }

        void Say(List<DialogueLine> lines, System.Action then)
        {
            if (lines == null || lines.Count == 0 || textbox == null)
            {
                then?.Invoke();
                return;
            }
            busy = true;
            textbox.Play(lines, () =>
            {
                busy = false;
                then?.Invoke();
            });
        }

        // ---------- stroke animation ----------

        IEnumerator Flash(Image img)
        {
            Color bright = new Color(1f, 1f, 0.55f, 0.85f);
            for (float t = 0f; t < 0.35f; t += Time.unscaledDeltaTime)
            {
                if (img == null) yield break;
                img.color = Color.Lerp(bright, confirmedColor, t / 0.35f);
                yield return null;
            }
            if (img != null) img.color = confirmedColor;
        }

        IEnumerator FadeAndRemove(Stroke s)
        {
            if (s.image != null)
            {
                Color c = s.image.color;
                float a0 = c.a;
                for (float t = 0f; t < wrongStrokeFade; t += Time.unscaledDeltaTime)
                {
                    if (s.image == null) break;
                    c.a = Mathf.Lerp(a0, 0f, t / wrongStrokeFade);
                    s.image.color = c;
                    yield return null;
                }
                if (s.image != null) Destroy(s.image.gameObject);
            }
            strokes.Remove(s);
        }
    }
}
