using System;
using System.Collections.Generic;
using UnityEngine;

namespace DukeHeirloom.Inspection
{
    /// <summary>One line of dialogue shown in the inspection textbox.</summary>
    [Serializable]
    public class DialogueLine
    {
        [Tooltip("Name on the nameplate, e.g. MC, PROF. Leave empty for narration. {name} is replaced with the player's name.")]
        public string speaker = "MC";

        [Tooltip("Inner monologue: nameplate gets ' (inner)' and the text is italic.")]
        public bool inner = true;

        [TextArea(2, 5)]
        public string text;

        public DialogueLine() { }

        public DialogueLine(string speaker, string text, bool inner = true)
        {
            this.speaker = speaker;
            this.text = text;
            this.inner = inner;
        }
    }

    /// <summary>
    /// Optional external dialogue source (e.g. an Ink story). If a FindingZone has an inkKnot and the
    /// board has a source assigned, lines come from here instead of the inspector lists.
    /// </summary>
    public interface IInspectionDialogueSource
    {
        /// <param name="quiet">Don't log a warning if the knot doesn't exist.</param>
        bool TryGetLines(string knot, List<DialogueLine> output, bool quiet = false);
    }

    public static class InspectionText
    {
        /// <summary>Set this from your name-input screen. Replaces {name} in all lines.</summary>
        public static string PlayerName = "Name";

        public static string Format(string s)
        {
            return string.IsNullOrEmpty(s) ? s : s.Replace("{name}", PlayerName);
        }
    }
}
