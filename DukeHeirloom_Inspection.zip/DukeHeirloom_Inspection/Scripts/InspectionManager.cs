using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DukeHeirloom.Inspection
{
    /// <summary>
    /// Bridge between your VN (Ink) flow and the inspection screens.
    /// Put it on a parent object that holds every InspectionBoard (police report, phone status, bank statement).
    ///
    /// From your dialogue manager:
    ///     if (InspectionManager.IsOpen) return;                 // ignore VN clicks while inspecting
    ///     InspectionManager.Open("police_report", ContinueStory); // story resumes when the player is done
    /// </summary>
    public class InspectionManager : MonoBehaviour
    {
        public static InspectionManager Instance { get; private set; }
        public static bool IsOpen => Instance != null && Instance.current != null;

        [Tooltip("Leave empty to auto-collect every InspectionBoard under this object.")]
        [SerializeField] List<InspectionBoard> boards = new List<InspectionBoard>();
        [SerializeField, Min(0f)] float fadeTime = 0.35f;

        [Tooltip("Hidden while a document is open, e.g. character sprites or the quick menu (Auto/Skip/Log).")]
        [SerializeField] List<GameObject> hideWhileInspecting = new List<GameObject>();

        [Tooltip("Testing only: open this inspection on Play without the VN. Clear it once your story opens it.")]
        [SerializeField] string testOpenOnStart = "";

        InspectionBoard current;
        Action onDone;
        readonly List<GameObject> hiddenByUs = new List<GameObject>();

        void Awake()
        {
            Instance = this;
            if (boards.Count == 0) GetComponentsInChildren(true, boards);
            foreach (var b in boards)
                if (b != null) b.gameObject.SetActive(false);
        }

        void Start()
        {
            if (!string.IsNullOrWhiteSpace(testOpenOnStart) && !IsOpen)
                OpenBoard(testOpenOnStart, () => Debug.Log($"[Inspection] '{testOpenOnStart}' finished → story would continue here."));
        }

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        /// <summary>Open a document by id. onDone runs after the player finishes and the screen fades out.</summary>
        public static bool Open(string id, Action onDone)
        {
            if (Instance == null)
            {
                Debug.LogError("[Inspection] No InspectionManager in the scene.");
                onDone?.Invoke();
                return false;
            }
            return Instance.OpenBoard(id, onDone);
        }

        public bool OpenBoard(string id, Action done)
        {
            if (current != null)
            {
                Debug.LogWarning($"[Inspection] '{current.inspectionId}' is already open.");
                return false;
            }
            var board = boards.Find(b => b != null && b.inspectionId == id);
            if (board == null)
            {
                Debug.LogError($"[Inspection] No InspectionBoard with id '{id}'. Story continues so the game doesn't get stuck.");
                done?.Invoke();
                return false;
            }

            current = board;
            onDone = done;

            hiddenByUs.Clear();
            foreach (var go in hideWhileInspecting)
            {
                if (go == null || !go.activeSelf) continue;
                go.SetActive(false);
                hiddenByUs.Add(go);
            }

            board.onFinished.AddListener(OnBoardFinished);
            board.gameObject.SetActive(true);
            StartCoroutine(Fade(board, 0f, 1f, null));
            return true;
        }

        void OnBoardFinished()
        {
            var board = current;
            board.onFinished.RemoveListener(OnBoardFinished);
            StartCoroutine(Fade(board, 1f, 0f, () =>
            {
                board.gameObject.SetActive(false);
                foreach (var go in hiddenByUs)
                    if (go != null) go.SetActive(true);
                hiddenByUs.Clear();

                current = null;
                var cb = onDone;
                onDone = null;
                cb?.Invoke();
            }));
        }

        IEnumerator Fade(InspectionBoard board, float from, float to, Action then)
        {
            if (!board.TryGetComponent(out CanvasGroup group)) group = board.gameObject.AddComponent<CanvasGroup>();
            group.blocksRaycasts = false; // no clicks mid-fade
            for (float t = 0f; t < fadeTime; t += Time.unscaledDeltaTime)
            {
                group.alpha = Mathf.Lerp(from, to, t / fadeTime);
                yield return null;
            }
            group.alpha = to;
            group.blocksRaycasts = to > 0.5f;
            then?.Invoke();
        }

        /// <summary>
        /// Reads an Ink tag like  #inspect:police_report  (or "#inspect police_report").
        /// Works with story.currentTags; no Ink dependency here.
        /// </summary>
        public static bool TryGetInspectTag(IList<string> tags, out string id)
        {
            id = null;
            if (tags == null) return false;
            foreach (var raw in tags)
            {
                var s = raw.Trim();
                if (!s.StartsWith("inspect", StringComparison.OrdinalIgnoreCase)) continue;
                int i = s.IndexOfAny(new[] { ':', ' ' });
                if (i < 0) continue;
                id = s.Substring(i + 1).Trim();
                if (id.Length > 0) return true;
            }
            id = null;
            return false;
        }
    }
}
