using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DukeHeirloom.Inspection
{
    /// <summary>
    /// Put this on the same Viewport as DocumentZoomPan. While ON, left-dragging draws a
    /// horizontal highlighter stroke (like swiping a marker across a line of text).
    /// Strokes live inside the document, so they zoom and pan with it.
    /// </summary>
    public class HighlighterTool : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler,
        IPointerEnterHandler, IPointerExitHandler
    {
        [SerializeField] InspectionBoard board;
        [Tooltip("Stretch-to-fill child of Content, above the document image.")]
        [SerializeField] RectTransform strokeLayer;

        [Header("Look")]
        [Tooltip("Optional marker texture. A soft-edged, 9-sliced sprite looks most like a real highlighter.")]
        [SerializeField] Sprite strokeSprite;
        [SerializeField] Color draftColor = new Color(1f, 0.93f, 0.25f, 0.45f);
        [Tooltip("Stroke thickness in document units (match roughly to your report's line height).")]
        [SerializeField, Min(4f)] float strokeHeight = 30f;
        [SerializeField, Min(1f)] float minStrokeWidth = 14f;

        [Header("Cursor (optional)")]
        [Tooltip("Texture import type must be 'Cursor'.")]
        [SerializeField] Texture2D cursorTexture;
        [SerializeField] Vector2 cursorHotspot = new Vector2(4, 28);

        public bool IsOn { get; private set; }

        RectTransform current;
        Vector2 start;
        bool drawing, hovering;
        Canvas canvas;

        Camera Cam => canvas == null || canvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : canvas.worldCamera;

        void Awake()
        {
            canvas = GetComponentInParent<Canvas>();
            if (canvas != null) canvas = canvas.rootCanvas;
        }

        public void SetOn(bool on)
        {
            IsOn = on;
            UpdateCursor();
        }

        public void OnBeginDrag(PointerEventData e)
        {
            drawing = IsOn && e.button == PointerEventData.InputButton.Left && board != null && board.CanHighlight;
            if (!drawing) return;

            // pressPosition = where the finger/mouse first went down, not where the drag threshold was crossed.
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(strokeLayer, e.pressPosition, Cam, out start))
            {
                drawing = false;
                return;
            }

            var go = new GameObject("Stroke", typeof(RectTransform), typeof(Image));
            current = (RectTransform)go.transform;
            current.SetParent(strokeLayer, false);
            current.anchorMin = current.anchorMax = new Vector2(0.5f, 0.5f);
            current.pivot = new Vector2(0f, 0.5f);

            var img = go.GetComponent<Image>();
            img.sprite = strokeSprite;
            img.type = strokeSprite != null && strokeSprite.border != Vector4.zero ? Image.Type.Sliced : Image.Type.Simple;
            img.color = draftColor;
            img.raycastTarget = false;

            UpdateStroke(start);
        }

        public void OnDrag(PointerEventData e)
        {
            if (!drawing || current == null) return;
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(strokeLayer, e.position, Cam, out var p))
                UpdateStroke(p);
        }

        public void OnEndDrag(PointerEventData e)
        {
            if (!drawing || current == null) return;
            drawing = false;

            Rect r = StrokeRect();
            if (r.width < minStrokeWidth)
            {
                Destroy(current.gameObject);
            }
            else
            {
                board.SubmitStroke(current.GetComponent<Image>(), r);
            }
            current = null;
        }

        Vector2 currentEnd;

        void UpdateStroke(Vector2 end)
        {
            currentEnd = end;
            Rect r = StrokeRect();
            // anchoredPosition is relative to the parent's centre (anchors 0.5), local points are relative to its pivot.
            current.anchoredPosition = new Vector2(r.xMin, start.y) - strokeLayer.rect.center;
            current.sizeDelta = new Vector2(r.width, strokeHeight);
        }

        /// <summary>Stroke rectangle in strokeLayer local space (same space the board tests in).</summary>
        Rect StrokeRect()
        {
            float x0 = Mathf.Min(start.x, currentEnd.x);
            float w = Mathf.Abs(currentEnd.x - start.x);
            return new Rect(x0, start.y - strokeHeight * 0.5f, w, strokeHeight);
        }

        // ---------- cursor ----------

        public void OnPointerEnter(PointerEventData e) { hovering = true; UpdateCursor(); }
        public void OnPointerExit(PointerEventData e) { hovering = false; UpdateCursor(); }

        void OnDisable()
        {
            hovering = false;
            UpdateCursor();
        }

        void UpdateCursor()
        {
            if (cursorTexture == null) return;
            if (IsOn && hovering) Cursor.SetCursor(cursorTexture, cursorHotspot, CursorMode.Auto);
            else Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
        }
    }
}
