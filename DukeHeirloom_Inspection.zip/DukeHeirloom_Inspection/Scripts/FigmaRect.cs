using UnityEngine;

namespace DukeHeirloom.Inspection
{
    /// <summary>
    /// Helper for placing finding lines straight from Figma numbers.
    /// In Figma, select the text you want highlightable and read X / Y / W / H (relative to the
    /// report frame). Type them here, then right-click the component header → "Apply Figma Rect".
    /// Requires the document frame in Unity to be the same size as the Figma frame (at 1x).
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    public class FigmaRect : MonoBehaviour
    {
        [Tooltip("The RectTransform that matches the Figma frame (usually 'Document' or 'Content').")]
        public RectTransform frame;
        public Vector2 figmaPosition;   // X, Y from Figma (top-left origin)
        public Vector2 figmaSize;       // W, H from Figma

        [ContextMenu("Apply Figma Rect")]
        public void Apply()
        {
            var rt = (RectTransform)transform;
            var parent = rt.parent as RectTransform;
            if (frame == null || parent == null)
            {
                Debug.LogWarning("FigmaRect: assign 'frame' first.", this);
                return;
            }
#if UNITY_EDITOR
            UnityEditor.Undo.RecordObject(rt, "Apply Figma Rect");
#endif
            Rect fr = frame.rect;
            // Figma: origin top-left, y down.  Unity: origin at pivot, y up.
            Vector2 frameLocalCenter = new Vector2(
                fr.xMin + figmaPosition.x + figmaSize.x * 0.5f,
                fr.yMax - (figmaPosition.y + figmaSize.y * 0.5f));

            Vector3 world = frame.TransformPoint(frameLocalCenter);
            Vector2 parentLocal = parent.InverseTransformPoint(world);

            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = parentLocal - parent.rect.center;

            float scale = frame.lossyScale.x / Mathf.Max(0.0001f, parent.lossyScale.x);
            rt.sizeDelta = figmaSize * scale;
        }
    }
}
