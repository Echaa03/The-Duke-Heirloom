using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DukeHeirloom.Inspection
{
    /// <summary>
    /// Bottom textbox with typewriter text. Click / Space / Enter: finish the line, then advance.
    /// While it's playing, a transparent click-catcher covers the screen so the player
    /// can't highlight in the middle of dialogue.
    /// If you already have a VN textbox, you can skip this and feed the board's events into yours.
    /// </summary>
    public class InspectionTextbox : MonoBehaviour
    {
        [SerializeField] GameObject panel;
        [SerializeField] GameObject nameplate;
        [SerializeField] TMP_Text nameText;
        [SerializeField] TMP_Text bodyText;
        [SerializeField] GameObject clickCatcher;
        [SerializeField] GameObject advanceIndicator;

        [SerializeField, Min(1f)] float charsPerSecond = 45f;
        [SerializeField] string innerSuffix = " (inner)";
        [SerializeField] bool italicInner = true;
        [SerializeField] bool hideWhenDone = true;

        [Tooltip("ON = 'panel', 'nameText' and 'bodyText' point at your VN's existing textbox. " +
                 "The panel is then never hidden by this script, only borrowed while inspecting.")]
        [SerializeField] bool sharedWithVN = false;

        public bool IsPlaying { get; private set; }

        List<DialogueLine> queue;
        int index;
        Action done;
        Coroutine typing;
        bool lineComplete;

        void Awake()
        {
            if (clickCatcher != null && clickCatcher.TryGetComponent(out Button b1)) b1.onClick.AddListener(ClickAdvance);
            if (panel != null && panel.TryGetComponent(out Button b2)) b2.onClick.AddListener(ClickAdvance);
            if (panel != null && !sharedWithVN) panel.SetActive(false);
            if (clickCatcher != null) clickCatcher.SetActive(false);
        }

        public void Play(IList<DialogueLine> lines, Action onDone)
        {
            if (lines == null || lines.Count == 0)
            {
                onDone?.Invoke();
                return;
            }
            queue = new List<DialogueLine>(lines);
            index = -1;
            done = onDone;
            IsPlaying = true;
            Deselect(); // so Space doesn't also "press" whatever button was last clicked
            if (panel != null) panel.SetActive(true);
            if (clickCatcher != null) clickCatcher.SetActive(true);
            Next();
        }

        public void Advance()
        {
            if (!IsPlaying) return;
            if (!lineComplete) CompleteLine();
            else Next();
        }

        void ClickAdvance()
        {
            Advance();
            Deselect();
        }

        static void Deselect()
        {
            if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
        }

        void Update()
        {
            if (IsPlaying && AdvancePressed()) Advance();
        }

        void Next()
        {
            index++;
            if (index >= queue.Count)
            {
                Finish();
                return;
            }
            Show(queue[index]);
        }

        void Show(DialogueLine line)
        {
            string speaker = InspectionText.Format(line.speaker);
            bool hasName = !string.IsNullOrWhiteSpace(speaker);
            if (nameplate != null) nameplate.SetActive(hasName);
            if (hasName && nameText != null) nameText.text = line.inner ? speaker + innerSuffix : speaker;

            string body = InspectionText.Format(line.text);
            if (line.inner && italicInner) body = "<i>" + body + "</i>";
            bodyText.text = body;
            bodyText.maxVisibleCharacters = 0;

            if (typing != null) StopCoroutine(typing);
            typing = StartCoroutine(Type());
        }

        IEnumerator Type()
        {
            lineComplete = false;
            if (advanceIndicator != null) advanceIndicator.SetActive(false);
            bodyText.ForceMeshUpdate();
            int total = bodyText.textInfo.characterCount;
            float shown = 0f;
            while (shown < total)
            {
                shown += charsPerSecond * Time.unscaledDeltaTime;
                bodyText.maxVisibleCharacters = (int)shown;
                yield return null;
            }
            typing = null;
            CompleteLine();
        }

        void CompleteLine()
        {
            if (typing != null)
            {
                StopCoroutine(typing);
                typing = null;
            }
            bodyText.maxVisibleCharacters = 99999;
            lineComplete = true;
            if (advanceIndicator != null) advanceIndicator.SetActive(true);
        }

        void Finish()
        {
            IsPlaying = false;
            if (hideWhenDone && !sharedWithVN && panel != null) panel.SetActive(false);
            if (clickCatcher != null) clickCatcher.SetActive(false);
            var cb = done;
            done = null;
            cb?.Invoke();
        }

        static bool AdvancePressed()
        {
#if ENABLE_INPUT_SYSTEM
            var k = UnityEngine.InputSystem.Keyboard.current;
            if (k != null && (k.spaceKey.wasPressedThisFrame || k.enterKey.wasPressedThisFrame)) return true;
#endif
#if ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return)) return true;
#endif
            return false;
        }
    }
}
