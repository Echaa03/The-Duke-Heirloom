using System.Collections.Generic;
using UnityEngine;

namespace DukeHeirloom.Inspection
{
    /// <summary>
    /// One "finding" on a document. Its Lines are invisible rectangles placed over the exact text
    /// the player must highlight. Lines can sit anywhere on the page — e.g. the friend's statement
    /// near the top and the family's statement further down — and ALL of them must be highlighted
    /// before the finding counts. That's how a contradiction is "caught".
    /// Lines only show as gizmos in the Scene view, never in the game.
    /// </summary>
    public class FindingZone : MonoBehaviour
    {
        public string id = "finding_01";

        [Tooltip("Rects the player must highlight. Leave empty to use this object's own rect.")]
        public List<RectTransform> lines = new List<RectTransform>();

        [Tooltip("How much of each line's width must be highlighted.")]
        [Range(0.3f, 1f)] public float requiredCoverage = 0.7f;

        [Tooltip("How far a stroke may run past the line (fraction of line width) and still count. " +
                 "Stops players from scribbling across the whole page.")]
        [Range(0f, 3f)] public float maxOverhang = 1f;

        [Header("Sticky note")]
        public string stickyTitle = "Findings :";
        [TextArea(3, 8)] public string stickyText;

        [Header("Dialogue")]
        [Tooltip("Optional: Ink knot to play instead of the lists below (needs an Ink source on the board). " +
                 "A knot named <knot>_partial is used for the partial line if it exists.")]
        public string inkKnot;
        [Tooltip("Plays when the finding is completed.")]
        public List<DialogueLine> dialogue = new List<DialogueLine>();
        [Tooltip("Plays once when only some of the lines are highlighted (multi-line findings).")]
        public List<DialogueLine> partialDialogue = new List<DialogueLine>();
        [Tooltip("MC's nudge after the player highlights wrong things a few times.")]
        [TextArea(2, 4)] public string hint;

        public bool IsFound { get; internal set; }
        internal bool partialPlayed;

        public IList<RectTransform> Targets
        {
            get
            {
                if (lines != null && lines.Count > 0) return lines;
                return new[] { (RectTransform)transform };
            }
        }

#if UNITY_EDITOR
        static readonly Vector3[] corners = new Vector3[4];

        void OnDrawGizmos()
        {
            Gizmos.color = IsFound ? new Color(0.2f, 0.9f, 0.3f, 0.9f) : new Color(1f, 0.55f, 0f, 0.9f);
            foreach (var rt in Targets)
            {
                if (rt == null) continue;
                rt.GetWorldCorners(corners);
                for (int i = 0; i < 4; i++) Gizmos.DrawLine(corners[i], corners[(i + 1) % 4]);
            }
        }
#endif
    }
}
