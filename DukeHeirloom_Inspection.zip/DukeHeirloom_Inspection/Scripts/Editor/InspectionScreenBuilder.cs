using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEditor.Events;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DukeHeirloom.Inspection.EditorTools
{
    /// <summary>
    /// Menu: Tools ▸ Duke Heirloom ▸ Create Inspection Screen
    /// Builds a complete, already-playable inspection screen with a placeholder police report
    /// and one sample finding (the 21:00 vs "never came home" contradiction).
    /// Swap the placeholder for your Figma export and move the finding lines.
    /// </summary>
    public static class InspectionScreenBuilder
    {
        static readonly Color Ink = new Color(0.16f, 0.13f, 0.1f);
        static readonly Color Dark = new Color(0.12f, 0.1f, 0.08f, 0.85f);
        static readonly Color Paper = new Color(0.97f, 0.96f, 0.92f);
        static readonly Color Sticky = new Color(1f, 0.89f, 0.42f);
        static readonly Color Beige = new Color(0.93f, 0.87f, 0.74f, 0.97f);

        [MenuItem("Tools/Duke Heirloom/Create Inspection Screen")]
        [MenuItem("GameObject/Duke Heirloom/Inspection Screen", false, 10)]
        static void Create()
        {
            // ---------- Canvas: use the selected one (your VN canvas), or make a new one ----------
            Canvas canvas = Selection.activeGameObject != null
                ? Selection.activeGameObject.GetComponentInParent<Canvas>()
                : null;
            if (canvas != null)
            {
                canvas = canvas.rootCanvas;
            }
            else
            {
                var canvasGO = new GameObject("InspectionCanvas", typeof(RectTransform), typeof(Canvas),
                    typeof(CanvasScaler), typeof(GraphicRaycaster));
                canvasGO.layer = LayerMask.NameToLayer("UI");
                canvas = canvasGO.GetComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                var scaler = canvasGO.GetComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1920, 1080);
                scaler.matchWidthOrHeight = 0.5f;
                Undo.RegisterCreatedObjectUndo(canvasGO, "Create Inspection Canvas");
            }

            if (Object.FindFirstObjectByType<EventSystem>() == null)
            {
                var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
                es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
                es.AddComponent<StandaloneInputModule>();
#endif
                Undo.RegisterCreatedObjectUndo(es, "Create EventSystem");
            }

            // ---------- Manager + screen ----------
            var inspections = UI("Inspections", canvas.transform);
            Stretch(inspections);
            Undo.RegisterCreatedObjectUndo(inspections.gameObject, "Create Inspection Screen");
            var manager = inspections.gameObject.AddComponent<InspectionManager>();
            var mso = new SerializedObject(manager);
            mso.FindProperty("testOpenOnStart").stringValue = "police_report";
            mso.ApplyModifiedPropertiesWithoutUndo();

            var screen = UI("Inspection_police_report", inspections);
            Stretch(screen);
            var board = screen.gameObject.AddComponent<InspectionBoard>();
            board.inspectionId = "police_report";

            // Semi-transparent: your BG-01 office stays visible behind the document.
            var bg = UI("Dim (BG shows through)", screen);
            Stretch(bg);
            Img(bg, new Color(0f, 0f, 0f, 0.55f), true);

            // ---------- Viewport / Content ----------
            var viewport = UI("Viewport", screen);
            Place(viewport, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(140, 110), new Vector2(1100, 800));
            Img(viewport, new Color(0f, 0f, 0f, 0.25f), true);
            viewport.gameObject.AddComponent<RectMask2D>();
            var zoomPan = viewport.gameObject.AddComponent<DocumentZoomPan>();
            var highlighter = viewport.gameObject.AddComponent<HighlighterTool>();

            var content = UI("Content (= Figma frame size)", viewport);
            Place(content, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1240, 1754));

            var doc = UI("Document (your Figma PNG)", content);
            Stretch(doc);
            Img(doc, Paper, false);
            BuildPlaceholderReport(doc);

            var strokes = UI("Strokes", content);
            Stretch(strokes);
            var zonesRoot = UI("Findings", content);
            Stretch(zonesRoot);

            // ---------- Sample finding: 21:00 vs never returned home ----------
            var zoneRT = UI("Finding_TimeMismatch", zonesRoot);
            Stretch(zoneRT);
            var zone = zoneRT.gameObject.AddComponent<FindingZone>();
            var lineFriend = UI("Line_FriendStatement", zoneRT);
            Place(lineFriend, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-10, 330), new Vector2(980, 40));
            var lineFamily = UI("Line_FamilyStatement", zoneRT);
            Place(lineFamily, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-10, 130), new Vector2(980, 40));
            foreach (var l in new[] { lineFriend, lineFamily })
            {
                var fr = l.gameObject.AddComponent<FigmaRect>();
                fr.frame = doc;
            }
            zone.id = "time_mismatch";
            zone.lines = new List<RectTransform> { lineFriend, lineFamily };
            zone.stickyText =
                "Friend: Sierra left for home around 21:00.\n" +
                "Family: she never came home.\n" +
                "→ Where did she go after nine?";
            zone.inkKnot = "police_report_time";
            zone.partialDialogue = new List<DialogueLine>
            {
                new DialogueLine("MC", "Hm... this doesn't sit right with something else in here."),
                new DialogueLine("MC", "Let me check the other statement."),
            };
            zone.dialogue = new List<DialogueLine>
            {
                new DialogueLine("MC", "Her friend says she left for home at nine..."),
                new DialogueLine("MC", "...but her family says she never came home."),
                new DialogueLine("MC", "How odd."),
            };
            zone.hint = "The witness statements... do the times actually line up?";
            EditorUtility.SetDirty(zone);

            // ---------- Sticky notes ----------
            var stickyArea = UI("StickyNotes", screen);
            Place(stickyArea, new Vector2(0, 1), new Vector2(0, 1), new Vector2(40, -40), new Vector2(380, 700));
            var vlg = stickyArea.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 22;
            vlg.childControlWidth = true;
            vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;

            var noteRT = UI("StickyNoteTemplate", screen);
            Place(noteRT, new Vector2(0, 1), new Vector2(0, 1), new Vector2(40, -40), new Vector2(380, 160));
            Img(noteRT, Sticky, true);
            var noteLayout = noteRT.gameObject.AddComponent<VerticalLayoutGroup>();
            noteLayout.padding = new RectOffset(20, 20, 16, 20);
            noteLayout.spacing = 8;
            noteLayout.childControlWidth = true;
            noteLayout.childControlHeight = true;
            noteLayout.childForceExpandHeight = false;
            var noteGroup = noteRT.gameObject.AddComponent<CanvasGroup>();
            var noteTitle = Text(noteRT, "Title", "Findings :", 24, Ink, TextAlignmentOptions.TopLeft);
            noteTitle.fontStyle = FontStyles.Bold;
            var noteBody = Text(noteRT, "Body", "…", 20, Ink, TextAlignmentOptions.TopLeft);
            var sticky = noteRT.gameObject.AddComponent<StickyNote>();
            SetRef(sticky, "title", noteTitle);
            SetRef(sticky, "body", noteBody);
            SetRef(sticky, "group", noteGroup);
            noteRT.gameObject.SetActive(false);

            // ---------- Toolbar ----------
            var bar = UI("Toolbar", screen);
            Place(bar, new Vector2(1, 1), new Vector2(1, 1), new Vector2(-40, -40), new Vector2(620, 64));
            var hlg = bar.gameObject.AddComponent<HorizontalLayoutGroup>();
            hlg.spacing = 10;
            hlg.childAlignment = TextAnchor.MiddleRight;
            hlg.childControlWidth = true;
            hlg.childControlHeight = true;
            hlg.childForceExpandWidth = false;

            var hlButton = Button(bar, "Btn_Highlighter", "Highlighter", 200);
            Wire(hlButton, board.ToggleHighlighter);
            Wire(Button(bar, "Btn_ZoomIn", "+", 64), zoomPan.ZoomIn);
            Wire(Button(bar, "Btn_ZoomOut", "–", 64), zoomPan.ZoomOut);
            Wire(Button(bar, "Btn_Reset", "Fit", 90), zoomPan.ResetView);
            Wire(Button(bar, "Btn_Clear", "Erase", 120), board.ClearHighlights);

            // ---------- Textbox ----------
            var tbRoot = UI("Textbox", screen);
            Stretch(tbRoot);
            var textbox = tbRoot.gameObject.AddComponent<InspectionTextbox>();

            var catcher = UI("ClickCatcher", tbRoot);
            Stretch(catcher);
            Img(catcher, new Color(0, 0, 0, 0), true);
            catcher.gameObject.AddComponent<Button>().transition = Selectable.Transition.None;

            var panel = UI("Panel (put your textbox art here)", tbRoot);
            Place(panel, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 30), new Vector2(1500, 230));
            Img(panel, Beige, true);
            panel.gameObject.AddComponent<Button>().transition = Selectable.Transition.None;

            var plate = UI("Nameplate", panel);
            Place(plate, new Vector2(0, 1), new Vector2(0, 0.5f), new Vector2(40, 0), new Vector2(280, 50));
            Img(plate, new Color(0.84f, 0.76f, 0.58f), false);
            var nameText = Text(plate, "Name", "MC (inner)", 26, Ink, TextAlignmentOptions.Center);
            nameText.fontStyle = FontStyles.Bold;
            Stretch(nameText.rectTransform);

            var body = Text(panel, "Body", "", 30, Ink, TextAlignmentOptions.TopLeft);
            Stretch(body.rectTransform, 60, 30, 70, 50);

            var arrow = UI("AdvanceIndicator", panel);
            Place(arrow, new Vector2(1, 0), new Vector2(0.5f, 0.5f), new Vector2(-40, 34), new Vector2(16, 16));
            arrow.localRotation = Quaternion.Euler(0, 0, 45);
            Img(arrow, Ink, false);

            SetRef(textbox, "panel", panel.gameObject);
            SetRef(textbox, "nameplate", plate.gameObject);
            SetRef(textbox, "nameText", nameText);
            SetRef(textbox, "bodyText", body);
            SetRef(textbox, "clickCatcher", catcher.gameObject);
            SetRef(textbox, "advanceIndicator", arrow.gameObject);

            // ---------- Continue ----------
            var cont = Button(screen, "Btn_Continue (wire to your story)", "Continue  ›", 220);
            Wire(cont, board.Finish);
            var contRT = (RectTransform)cont.transform;
            Place(contRT, new Vector2(1, 0), new Vector2(1, 0), new Vector2(-60, 290), new Vector2(220, 64));

            // ---------- References ----------
            SetRef(zoomPan, "content", content);
            SetRef(highlighter, "board", board);
            SetRef(highlighter, "strokeLayer", strokes);
            SetRef(board, "zoomPan", zoomPan);
            SetRef(board, "highlighter", highlighter);
            SetRef(board, "strokeLayer", strokes);
            SetRef(board, "textbox", textbox);
            SetRef(board, "stickyNoteArea", stickyArea);
            SetRef(board, "stickyNotePrefab", sticky);
            SetRef(board, "highlighterIndicator", hlButton.GetComponent<Image>());
            SetRef(board, "continueButton", cont.gameObject);

            // Textbox must be drawn last (on top of everything).
            tbRoot.SetAsLastSibling();

            Selection.activeGameObject = screen.gameObject;
            Debug.Log("Inspection screen created. Press Play and swipe across the two witness statements. " +
                      "When your story opens it instead, clear 'Test Open On Start' on the Inspections object.");
        }

        // ---------- placeholder report so the demo works out of the box ----------

        static void BuildPlaceholderReport(RectTransform doc)
        {
            var title = Text(doc, "PH_Title", "POLICE REPORT — MISSING PERSON\n<size=60%>Case No. 2026-0918 · Victim: SIERRA</size>",
                52, Ink, TextAlignmentOptions.Center);
            Place(title.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -90), new Vector2(1100, 160));

            string[] rows =
            {
                "Reporting party: Family of the victim. Report filed 48 hours after last contact.",
                "Witness (friend): The victim left for home at approximately 21:00.",
                "Witness confirms the victim did not appear distressed at the time.",
                "Statement (family): The victim never returned home that night.",
                "No signs of forced entry at the victim's residence.",
                "Status: Under investigation. No further leads at this time.",
            };
            for (int i = 0; i < rows.Length; i++)
            {
                var t = Text(doc, "PH_Row" + i, rows[i], 30, Ink, TextAlignmentOptions.Left);
                t.textWrappingMode = TextWrappingModes.NoWrap;
                Place(t.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, 430 - i * 100), new Vector2(1000, 40));
            }

            var note = Text(doc, "PH_Note", "<i>(Placeholder — replace the Document image with your Figma export and delete PH_ objects.)</i>",
                24, new Color(0.5f, 0.45f, 0.4f), TextAlignmentOptions.Center);
            Place(note.rectTransform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 120), new Vector2(1100, 60));
        }

        // ---------- helpers ----------

        static RectTransform UI(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = LayerMask.NameToLayer("UI");
            var rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            return rt;
        }

        static void Stretch(RectTransform rt, float left = 0, float bottom = 0, float right = 0, float top = 0)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.offsetMin = new Vector2(left, bottom);
            rt.offsetMax = new Vector2(-right, -top);
        }

        static void Place(RectTransform rt, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
        {
            rt.anchorMin = rt.anchorMax = anchor;
            rt.pivot = pivot;
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
        }

        static Image Img(RectTransform rt, Color c, bool raycast)
        {
            var img = rt.gameObject.AddComponent<Image>();
            img.color = c;
            img.raycastTarget = raycast;
            return img;
        }

        static TextMeshProUGUI Text(Transform parent, string name, string text, float size, Color color, TextAlignmentOptions align)
        {
            var rt = UI(name, parent);
            var t = rt.gameObject.AddComponent<TextMeshProUGUI>();
            t.text = text;
            t.fontSize = size;
            t.color = color;
            t.alignment = align;
            t.raycastTarget = false;
            return t;
        }

        static Button Button(Transform parent, string name, string label, float width)
        {
            var rt = UI(name, parent);
            Img(rt, Dark, true);
            var b = rt.gameObject.AddComponent<Button>();
            var le = rt.gameObject.AddComponent<LayoutElement>();
            le.preferredWidth = width;
            le.preferredHeight = 64;
            var t = Text(rt, "Label", label, 26, new Color(0.96f, 0.92f, 0.82f), TextAlignmentOptions.Center);
            Stretch(t.rectTransform);
            return b;
        }

        static void Wire(Button b, UnityAction action) => UnityEventTools.AddPersistentListener(b.onClick, action);

        static void SetRef(Object target, string field, Object value)
        {
            var so = new SerializedObject(target);
            var p = so.FindProperty(field);
            if (p == null)
            {
                Debug.LogError($"Builder: field '{field}' not found on {target.GetType().Name}");
                return;
            }
            p.objectReferenceValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }
    }
}
