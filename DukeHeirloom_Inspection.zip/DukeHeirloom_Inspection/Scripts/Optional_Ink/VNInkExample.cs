// REFERENCE: a minimal Ink dialogue loop showing the 3 lines (marked ★) to copy into YOUR dialogue manager.
// You can also use it as-is if you don't have a manager yet.
using System.Text.RegularExpressions;
using Ink.Runtime;
using TMPro;
using UnityEngine;

namespace DukeHeirloom.Inspection
{
    public class VNInkExample : MonoBehaviour
    {
        [SerializeField] TextAsset mainStoryJson;
        [SerializeField] TMP_Text nameText;
        [SerializeField] TMP_Text bodyText;

        Story story;
        string pendingInspection;

        static readonly Regex SpeakerLine =
            new Regex(@"^(?<name>[A-Za-z\?\.' ]{1,24}?)\s*(?<inner>\(inner\))?\s*:\s*(?<text>.+)$");

        void Start()
        {
            story = new Story(mainStoryJson.text);
            ShowNext();
        }

        /// <summary>Hook this to your textbox click / Space.</summary>
        public void OnAdvance()
        {
            // ★ 1. While a document is open, the VN ignores clicks (the inspection uses them).
            if (InspectionManager.IsOpen) return;

            // ★ 2. The line just shown had #inspect:xxx → open the document now.
            //      ShowNext runs AFTER the player finishes it, so the story picks up right where it left off.
            if (pendingInspection != null)
            {
                string id = pendingInspection;
                pendingInspection = null;
                InspectionManager.Open(id, ShowNext);
                return;
            }

            ShowNext();
        }

        void ShowNext()
        {
            if (!story.canContinue) return; // choices / end of story go here

            string line = story.Continue().Trim();

            // ★ 3. Remember if this line asks for an inspection after it.
            InspectionManager.TryGetInspectTag(story.currentTags, out pendingInspection);

            if (line.Length == 0)
            {
                OnAdvance(); // tag-only line: skip straight on
                return;
            }

            var m = SpeakerLine.Match(line);
            if (m.Success)
            {
                nameText.transform.parent.gameObject.SetActive(true);
                nameText.text = m.Groups["name"].Value.Trim() + (m.Groups["inner"].Success ? " (inner)" : "");
                string text = m.Groups["text"].Value.Trim();
                bodyText.text = m.Groups["inner"].Success ? "<i>" + text + "</i>" : text;
            }
            else
            {
                nameText.transform.parent.gameObject.SetActive(false);
                bodyText.text = line;
            }
        }

        void Update()
        {
#if ENABLE_INPUT_SYSTEM
            var k = UnityEngine.InputSystem.Keyboard.current;
            if (k != null && k.spaceKey.wasPressedThisFrame) OnAdvance();
#elif ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(KeyCode.Space)) OnAdvance();
#endif
        }
    }
}
