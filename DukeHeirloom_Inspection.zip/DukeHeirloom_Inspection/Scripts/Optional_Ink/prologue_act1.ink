// THE DUKE HEIRLOOM — Prologue, Act 1 (main story)
// Shows WHERE the inspections plug in. Tags:
//   #inspect:<id>   → after the player reads this line, open that document; story resumes when it's done
//   #prof:<expr>    → professor sprite expression (each one = one expression to commission)
//   #bg / #bgm / #sfx / #scene → your existing scene cues
// Lines marked // [ADDED] are bridges I wrote; everything else follows your script (grammar lightly fixed).

-> prologue_act1

=== prologue_act1 ===
// [BG-01: Ruang kerja universitas]
NARRATION: 10:47 PM. The faculty building had emptied hours ago. #bg:univ_office #bgm:piano_soft #sfx:clock_tick
NARRATION: Everyone except two people.
MC (inner): Three weeks since Sierra went missing. And yet another week of us going through this file...
MC (inner): ...and this report still reads like nobody's in a hurry. #inspect:police_report

// ── back from INSPECTION-01 (police report: 21:00 vs never came home) ──
// [ADDED]
MC (inner): Her phone records should be in here too. Where did the signal stop? #inspect:phone_status

// ── back from INSPECTION-02 (last ping 23:40, old shopping district) ──
MC (inner): And this was extracted from her bank account. #inspect:bank_statement

// ── back from INSPECTION-03 (antique hand mirror) ──
-> scene_1_3

=== scene_1_3 ===
MC: Professor?
PROF: Yes? Did you find something? #prof:curious
MC: It's about the case. There are two things that don't add up.
PROF: Only two? The police did better than usual, then. #prof:smirk
MC: Her phone was last detected at 11:40 PM in the old shopping district. That's nowhere near the route she usually takes home.
PROF: Well, you never know. People take detours. #prof:skeptic
MC: For almost three hours? On a weeknight, without telling her family? Her friend's statement says she had a morning lab the next day.
PROF: ...Continue. #prof:serious
MC: Also, for the record, she bought an antique hand mirror from a shop that says it has never sold any mirrors. The police logged it as a typo.
PROF: How so?
MC: A typo changes a number, professor. It doesn't invent an entirely new item.
-> scene_1_4

=== scene_1_4 ===
PROF: Well. That's a valid point. #prof:slight_smile
PROF: Either way, the police have had this file for three weeks. #prof:flat
MC: And no one even bothered to go back to that shop?
PROF: Then that's your assignment tomorrow. Go talk to the owner yourself and bring back your own notes. #prof:serious
MC: Huh!? Me??
PROF: Obviously. Who else? You're the one who found it, aren't you? I didn't hire you as my assistant for nothing. #prof:smirk
PROF: It's getting late. I wouldn't recommend staying here any longer. Go home, we'll discuss the rest tomorrow. #prof:serious
MC: Understood. Thank you, professor.
// [Scene! MC keluar dari ruang professor]
#scene:mc_leaves_office #sfx:door_close
MC (inner): Old shopping district, huh... that's right on my way home.
-> END
