// Prologue Act 1 — Scene 1.2 inspection lines.
// Knot names match the "Ink Knot" field on each FindingZone.
// <knot>_partial plays once when only part of a multi-line finding is highlighted.

// ───── INSPECTION-01 : Police report ─────
// Player must highlight BOTH the friend's statement and the family's statement.

=== police_report_time_partial ===
MC (inner): Hm... this doesn't sit right with something else in here.
MC (inner): Let me check the other statement.
-> DONE

=== police_report_time ===
MC (inner): Her friend says she left for home at nine...
MC (inner): ...but her family says she never came home.
MC (inner): How odd.
-> DONE

// ───── INSPECTION-02 : Last phone status ─────

=== phone_status_location ===
MC (inner): Huh... but her phone pinged at 11:40 PM, at... here?
MC (inner): That's nowhere near her home. Why would she go that far?
MC (inner): Two hours and forty minutes.
MC (inner): Where were you, Sierra...?
-> DONE

// ───── INSPECTION-03 : Bank statement ─────

=== bank_statement_mirror ===
MC (inner): "Antique Hand Mirror." Bought one week before she disappeared.
MC (inner): And the police note says the shop owner has never stocked mirrors... so they logged it as a cashier input error.
MC (inner): Input error, my ass.
MC (inner): How do you even mistype something that was never there to begin with?
-> DONE
