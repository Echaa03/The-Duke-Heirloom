// Needs the Ink Unity Integration package (you already have it if the "Ink Player" window exists).
// If you don't use Ink, delete this folder.
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Ink.Runtime;
using UnityEngine;

namespace DukeHeirloom.Inspection
{
    /// <summary>
    /// Lets FindingZones pull their lines from Ink knots so all your writing stays in .ink files.
    /// Line format in Ink:   MC (inner): Her friend says she left at nine...
    ///                       PROF: Continue.
    ///                       Narration with no speaker prefix.
    /// </summary>
    public class InkInspectionSource : MonoBehaviour, IInspectionDialogueSource
    {
        [Tooltip("Compiled ink JSON. Recommended: a small separate file just for inspections (inspection.ink).")]
        [SerializeField] TextAsset inkJson;

        [Tooltip("Only if you pass in your MAIN story via the Story property: restores its position after " +
                 "the knot plays. Note this also undoes any variable changes made inside the knot.")]
        [SerializeField] bool restoreStateAfter = false;

        Story story;

        static readonly Regex SpeakerLine =
            new Regex(@"^(?<name>[A-Za-z\?\.' ]{1,24}?)\s*(?<inner>\(inner\))?\s*:\s*(?<text>.+)$");

        /// <summary>Assign your own Story here to share variables with the main script.</summary>
        public Story Story
        {
            get
            {
                if (story == null && inkJson != null) story = new Story(inkJson.text);
                return story;
            }
            set => story = value;
        }

        public bool TryGetLines(string knot, List<DialogueLine> output, bool quiet = false)
        {
            var s = Story;
            if (s == null) return false;

            string saved = restoreStateAfter ? s.state.ToJson() : null;
            try
            {
                s.ChoosePathString(knot);
            }
            catch (Exception e)
            {
                if (!quiet) Debug.LogWarning($"Ink knot '{knot}' not found: {e.Message}", this);
                return false;
            }

            while (s.canContinue)
            {
                string raw = s.Continue().Trim();
                if (raw.Length == 0) continue;
                output.Add(Parse(raw, s.currentTags));
            }

            if (saved != null) s.state.LoadJson(saved);
            return output.Count > 0;
        }

        static DialogueLine Parse(string raw, List<string> tags)
        {
            bool innerTag = tags != null && tags.Contains("inner");
            var m = SpeakerLine.Match(raw);
            if (!m.Success) return new DialogueLine("", raw, innerTag);
            return new DialogueLine(m.Groups["name"].Value.Trim(), m.Groups["text"].Value.Trim(),
                m.Groups["inner"].Success || innerTag);
        }
    }
}
