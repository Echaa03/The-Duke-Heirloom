using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

namespace DukeHeirloom.Inspection
{
    /// <summary>
    /// Put this on the Viewport (a RectTransform with RectMask2D + a raycastable Image).
    /// Its child "Content" holds the document. Mouse wheel zooms toward the cursor,
    /// right/middle drag always pans, left drag pans only when the highlighter is off.
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    public class DocumentZoomPan : MonoBehaviour, IScrollHandler, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        [SerializeField] RectTransform content;

        [Tooltip("Max zoom = 'fit whole page' zoom x this value.")]
        [SerializeField, Min(1f)] float maxZoomMultiplier = 3f;
        [SerializeField, Range(1.01f, 2f)] float wheelStep = 1.15f;
        [SerializeField, Range(1.01f, 2f)] float buttonStep = 1.35f;
        [Tooltip("0 = instant zoom.")]
        [SerializeField, Min(0f)] float smoothTime = 0.08f;
        [Tooltip("How far (in viewport units) the page may be dragged past its edge.")]
        [SerializeField, Min(0f)] float edgePadding = 40f;

        [HideInInspector] public bool leftDragPans = true;

        RectTransform viewport;
        Canvas canvas;
        float minZoom = 1f, maxZoom = 3f, targetZoom = 1f;
        Vector2 zoomPivotScreen;
        bool panning;
        Coroutine focusRoutine;

        public RectTransform Content => content;
        public float Zoom => content.localScale.x;

        Camera Cam => canvas == null || canvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : canvas.worldCamera;
        float CanvasScale => canvas != null ? canvas.scaleFactor : 1f;

        void Awake()
        {
            viewport = (RectTransform)transform;
            canvas = GetComponentInParent<Canvas>();
            if (canvas != null) canvas = canvas.rootCanvas;

            // The math below assumes content is centred in the viewport.
            Vector2 size = content.rect.size;
            content.anchorMin = content.anchorMax = content.pivot = new Vector2(0.5f, 0.5f);
            content.sizeDelta = size;
        }

        void Start() => ResetView();

        void OnRectTransformDimensionsChange()
        {
            if (viewport == null || content == null || !isActiveAndEnabled) return;
            RecalcLimits();
            targetZoom = Mathf.Clamp(targetZoom, minZoom, maxZoom);
            SetZoomImmediate(targetZoom, ViewportCenterScreen());
        }

        void RecalcLimits()
        {
            Vector2 v = viewport.rect.size, c = content.rect.size;
            if (c.x <= 0f || c.y <= 0f || v.x <= 0f || v.y <= 0f) return;
            minZoom = Mathf.Min(v.x / c.x, v.y / c.y);   // whole page visible
            maxZoom = minZoom * maxZoomMultiplier;
        }

        // ---------- public API (hook these to buttons) ----------

        public void ZoomIn() => ZoomBy(buttonStep, ViewportCenterScreen());
        public void ZoomOut() => ZoomBy(1f / buttonStep, ViewportCenterScreen());

        public void ResetView()
        {
            StopFocus();
            RecalcLimits();
            targetZoom = minZoom;
            content.localScale = new Vector3(minZoom, minZoom, 1f);
            content.anchoredPosition = Vector2.zero;
        }

        public void ZoomBy(float factor, Vector2 screenPoint)
        {
            StopFocus();
            targetZoom = Mathf.Clamp(targetZoom * factor, minZoom, maxZoom);
            zoomPivotScreen = screenPoint;
        }

        /// <summary>Smoothly zoom so that a point (in Content local space) is centred.</summary>
        public void FocusOnLocal(Vector2 contentLocalPoint, float zoomMultiplier = 1.8f, float duration = 0.45f)
        {
            StopFocus();
            float z = Mathf.Clamp(minZoom * zoomMultiplier, minZoom, maxZoom);
            focusRoutine = StartCoroutine(FocusRoutine(contentLocalPoint, z, duration));
        }

        // ---------- input ----------

        public void OnScroll(PointerEventData e)
        {
            if (Mathf.Approximately(e.scrollDelta.y, 0f)) return;
            ZoomBy(e.scrollDelta.y > 0f ? wheelStep : 1f / wheelStep, e.position);
        }

        bool CanPan(PointerEventData e) =>
            e.button == PointerEventData.InputButton.Right ||
            e.button == PointerEventData.InputButton.Middle ||
            (e.button == PointerEventData.InputButton.Left && leftDragPans);

        public void OnBeginDrag(PointerEventData e)
        {
            panning = CanPan(e);
            if (panning) StopFocus();
        }

        public void OnDrag(PointerEventData e)
        {
            if (!panning) return;
            content.anchoredPosition = ClampPos(content.anchoredPosition + e.delta / CanvasScale, Zoom);
        }

        public void OnEndDrag(PointerEventData e) => panning = false;

        // ---------- internals ----------

        void Update()
        {
            if (focusRoutine != null) return;
            float z = Zoom;
            if (Mathf.Abs(z - targetZoom) < 0.0005f)
            {
                if (z != targetZoom) SetZoomImmediate(targetZoom, zoomPivotScreen);
                return;
            }
            float next = smoothTime <= 0f
                ? targetZoom
                : Mathf.Lerp(z, targetZoom, 1f - Mathf.Exp(-Time.unscaledDeltaTime / smoothTime));
            SetZoomImmediate(next, zoomPivotScreen);
        }

        void SetZoomImmediate(float zoom, Vector2 screenPoint)
        {
            // Keep the point under the cursor fixed while zooming.
            RectTransformUtility.ScreenPointToLocalPointInRectangle(content, screenPoint, Cam, out var before);
            content.localScale = new Vector3(zoom, zoom, 1f);
            RectTransformUtility.ScreenPointToLocalPointInRectangle(content, screenPoint, Cam, out var after);
            content.anchoredPosition = ClampPos(content.anchoredPosition + (after - before) * zoom, zoom);
        }

        Vector2 ClampPos(Vector2 p, float zoom)
        {
            Vector2 v = viewport.rect.size;
            Vector2 c = content.rect.size * zoom;
            p.x = ClampAxis(p.x, c.x, v.x);
            p.y = ClampAxis(p.y, c.y, v.y);
            return p;
        }

        float ClampAxis(float pos, float contentSize, float viewSize)
        {
            if (contentSize <= viewSize) return 0f;
            float limit = (contentSize - viewSize) * 0.5f + edgePadding;
            return Mathf.Clamp(pos, -limit, limit);
        }

        IEnumerator FocusRoutine(Vector2 local, float zoom, float duration)
        {
            float z0 = Zoom;
            Vector2 p0 = content.anchoredPosition;
            Vector2 p1 = ClampPos(-local * zoom, zoom);
            for (float t = 0f; t < duration; t += Time.unscaledDeltaTime)
            {
                float k = Mathf.SmoothStep(0f, 1f, t / duration);
                float z = Mathf.Lerp(z0, zoom, k);
                content.localScale = new Vector3(z, z, 1f);
                content.anchoredPosition = ClampPos(Vector2.Lerp(p0, p1, k), z);
                yield return null;
            }
            content.localScale = new Vector3(zoom, zoom, 1f);
            content.anchoredPosition = p1;
            targetZoom = zoom;
            focusRoutine = null;
        }

        void StopFocus()
        {
            if (focusRoutine == null) return;
            StopCoroutine(focusRoutine);
            focusRoutine = null;
            targetZoom = Zoom;
        }

        Vector2 ViewportCenterScreen() =>
            RectTransformUtility.WorldToScreenPoint(Cam, viewport.TransformPoint(viewport.rect.center));
    }
}
