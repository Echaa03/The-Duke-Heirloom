using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

namespace DukeHeirloom.Inspection
{
    /// <summary>Yellow findings note. Pops in with a slight tilt; clicking it zooms the document back to the finding.</summary>
    public class StickyNote : MonoBehaviour, IPointerClickHandler
    {
        [SerializeField] TMP_Text title;
        [SerializeField] TMP_Text body;
        [SerializeField] CanvasGroup group;
        [SerializeField, Min(0.01f)] float popDuration = 0.35f;
        [SerializeField] Vector2 tiltRange = new Vector2(-3f, 3f);

        Action onClick;

        public void Setup(string titleText, string bodyText, Action clicked)
        {
            if (title != null) title.text = InspectionText.Format(titleText);
            if (body != null) body.text = InspectionText.Format(bodyText);
            onClick = clicked;
            StartCoroutine(Pop());
        }

        IEnumerator Pop()
        {
            var t = transform;
            t.localRotation = Quaternion.Euler(0f, 0f, UnityEngine.Random.Range(tiltRange.x, tiltRange.y));
            for (float time = 0f; time < popDuration; time += Time.unscaledDeltaTime)
            {
                float k = time / popDuration;
                // ease-out-back: overshoots a little, like slapping a note onto a desk
                const float c1 = 1.70158f, c3 = c1 + 1f;
                float s = 1f + c3 * Mathf.Pow(k - 1f, 3f) + c1 * Mathf.Pow(k - 1f, 2f);
                t.localScale = Vector3.one * Mathf.LerpUnclamped(0.6f, 1f, s);
                if (group != null) group.alpha = Mathf.Clamp01(k * 2f);
                yield return null;
            }
            t.localScale = Vector3.one;
            if (group != null) group.alpha = 1f;
        }

        public void OnPointerClick(PointerEventData e) => onClick?.Invoke();
    }
}
